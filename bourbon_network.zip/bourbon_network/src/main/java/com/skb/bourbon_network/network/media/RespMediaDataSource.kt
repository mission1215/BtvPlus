package com.skb.bourbon_network.network.media

class RespMediaDataSource {
}
data class MediaItem(
    val id: String,
    val title: String,
    val uri: String,
)